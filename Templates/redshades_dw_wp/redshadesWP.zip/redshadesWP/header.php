<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>
<?php bloginfo('name'); ?>
<?php wp_title(); ?>
</title>
<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.ico" type="image/x-icon" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/wp-style.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/css/grid-960.css" type="text/css" media="screen" />
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all posts', ''); ?>" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/rss+xml" title="<?php _e('RSS 2.0 - all comments', ''); ?>" href="<?php bloginfo('comments_rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if(is_singular()) wp_enqueue_script('comment-reply'); ?>
<?php wp_head(); ?>
<script type="text/javascript">  // This script is for the navigation menu
    jQuery(document).ready(function(){ 
		jQuery("#nav a").removeAttr("title"); 
        jQuery("ul.sf-menu").supersubs({ 
            minWidth:    12,   // minimum width of sub-menus in em units 
            maxWidth:    27,   // maximum width of sub-menus in em units 
            extraWidth:  2     // extra width can ensure lines don't sometimes turn over 
                               // due to slight rounding differences and font-family 
        }).superfish();  // call supersubs first, then superfish, so that subs are 
                         // not display:none when measuring. Call before initialising 
                         // containing tabs for same reason. 
		jQuery("#nav2 a").removeAttr("title"); 
		jQuery(".sidebarbox li a").removeAttr("title"); 
    }); 
</script>
<!-- If you wish to use the feature slider on your blog, remove this commented line and the closing comment bracket following the </script> tag below. Also remove the comment brackets around the feature area below the header code.
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('.slideshow').cycle({ // see http://malsup.com/jquery/cycle/ for jQuery cycle options
		fx:  'fade', // options are: blindX, blindY, blindZ, cover, curtainX, curtainY, fade, fadeZoom, growX, growY, scrollUp, scrollDown, scrollLeft, scrollRight, scrollHorz, scrollVert, shuffle, slideX, slideY, toss, turnUp, turnDown, turnLeft, turnRight, uncover, wipe, zoom
		timeout: 5000, // how long slides are shown in ms
    	speed:  1000, // how long transition takes in ms
		easing: 'easeInOutQuad', // options are: easeInOutQuad, easeInOutCubic, easeInOutQuart, easeInOutQuint, easeInOutSine, easeInOutExpo, easeInOutCirc, easeInOutElastic, easeInOutBack, easeInOutBounce
		pause: 1,
		pauseOnPagerHover: 1, // pause slideshow when mouse hovers
		sync: 1, // set to 1 to see two slides at the same time
		autostop: 0,
		pager: '#slidenav' // container element for optional slideshow navigation
		});
	})
</script>
remove this to show feature-->
</head>
<body>
<div id="header">
  <div class="container_12">
    <div class="grid_4"><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/logo.jpg" alt="<?php bloginfo('name'); ?>" /></a></div>
    <div id="nav" class="grid_8">
      <?php if ( function_exists('wp_nav_menu') ) {
	wp_nav_menu( array('echo' => '1', 'menu_class' => 'sf-menu', 'fallback_cb' => 'twonine_menu'));
	} else { ?>
      <ul class="sf-menu">
        <li<?php if (is_home()) { echo ' class="current_page_item"'; } ?>><a href="<?php echo get_settings('home'); ?>"><span>Home</span></a></li>
        <?php echo wp_list_pages('echo=0&orderby=name&exclude=&title_li='); ?>
      </ul>
      <?php } ?>
    </div>
  </div>
</div>
<!-- If you wish to use the feature slider on your blog, remove this commented line and the closing comment bracket 14 lines below
<div id="feature">
  <div class="container_12">
    <div class="grid_5">
      <p class="feature-title">Welcome to blackshades.</p>
      <p>A Dreamweaver template that's easily customizable for whatever content you want to use.</p>
      <p>W3C valid code and SEO optimization ensures your sites reach their potential.</p>
      <a href="#"><img src="<?php bloginfo('template_url'); ?>/images/btn-read-more.jpg" alt="" /></a><a href="#"><img src="<?php bloginfo('template_url'); ?>/images/btn-buy-now.jpg" alt="" style="margin-left:10px;"/></a></div>
    <div class="grid_7">
      <div class="slideshow"> <img src="<?php bloginfo('template_url'); ?>/images/slide1.jpg" alt="" /> <img src="<?php bloginfo('template_url'); ?>/images/slide2.jpg" alt="" /> </div>
</div>
</div>
<div class="clear"></div>
</div>
remove this line to show feature -->



<!-- If you wish to use the sub feature area on your blog, remove this commented line and the closing comment bracket 21 lines below
<div id="subfeature">
  <div class="container_12">
    <div class="grid_7">
      <p class="subtitle">Get Updates and Special Offers via Email</p>
      <p class="subtext">Just for subscribing to our updates you'll receive a ton of free goodies!</p>
    </div>
    <div class="grid_5">
      <form action="#" method="get" name="optinform" id="optinform" style="margin-top:8px;">
        <input name="name" type="text" class="optinname" value="Enter your name"  onfocus="if (this.value == 'Enter your name') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Enter your name';}"/>
        <input name="email" type="text" class="optinemail" value="Email address"  onfocus="if (this.value == 'Email address') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Email address';}"/>
        <input name="submit" type="button" class="submitbtn" value="GO" />
        <br />
        <p class="smallitalic">Your privacy is always respected! Read our <a href="#">privacy policy</a>.</p>
      </form>
    </div>
  </div>
  <div class="clear"></div>
</div>
remove this line to show sub feature -->