<div id="footer" class="container_12">
  <div class="grid_12">Copyright &copy; <script type="text/javascript" language="JavaScript">
  <!-- 
  var today = new Date();
  document.write(today.getFullYear());
  //-->
  </script>
  <a href="<?php echo get_option('home'); ?>/"><?php echo bloginfo('name');?></a>
  </div>
</div>
<?php wp_footer(); ?>
</body></html>